===========
policy.yaml
===========

Use the ``policy.yaml`` file to define additional access controls that apply to
the Identity service:

.. literalinclude:: ../../_static/keystone.policy.yaml.sample
