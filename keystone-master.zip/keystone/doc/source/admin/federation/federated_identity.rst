==================
Federated Identity
==================

.. toctree::
    :maxdepth: 2

    introduction.rst
    configure_federation.rst
    mapping_combinations.rst
